package finalexam;

// Aimar Sagastizabal

public class Assignment1 {

	public static void main(String[] args) {


	}

}
