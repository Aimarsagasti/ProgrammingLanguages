package finalexam;

//Aimar Sagastizabal

public class Assignment2 {

	public static void main(String[] args) {
		
		

	}

}
