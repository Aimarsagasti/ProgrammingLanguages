package Ass2;

public class Bird implements Flyer{

	
	public void takeoff() {
		
		System.out.println("Bird will take off from the next.");
		
	}

	
	public void land() {
		System.out.println("Bird has landed on the nest.");		
	}

	
	public void fly() {
		System.out.println("Bird flies above the river.");
		
	}
	
	public void buildNest() {
		System.out.println("The Bird has built the nest.");
		
	}
	
	public void layEggs() {
		
		System.out.println("The Bird has layed eggs in the nest. ");
		
	}

}
