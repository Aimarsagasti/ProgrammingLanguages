package Ass2;

public interface Flyer {
	
	public void takeoff();
	
	public void land();
	
	public void fly();

}
