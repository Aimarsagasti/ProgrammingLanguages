package Ass2;

public class Test {

	public static void main(String[] args) {
		
		Airplane plane1 = new Airplane();
		
		Bird bird1 = new Bird();
		
		Superman superman1 = new Superman();
		
		plane1.takeoff();
		plane1.land();
		plane1.fly();
		
		bird1.takeoff();
		bird1.land();
		bird1.fly();
		bird1.buildNest();
		bird1.layEggs();
		
		superman1.takeoff();
		superman1.land();
		superman1.fly();
		superman1.leapBuilding();
		superman1.stopBullet();

	}

}
