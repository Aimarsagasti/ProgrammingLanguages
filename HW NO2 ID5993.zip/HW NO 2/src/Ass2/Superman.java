package Ass2;

public class Superman implements Flyer{

	
	public void takeoff() {
		System.out.println("Superman takes off.");
		
	}

	
	public void land() {
		System.out.println("Superman has landed.");
		
	}

	
	public void fly() {
		System.out.println("Superman flies like an airplane.");
		
	}
	
	public void leapBuilding() {
		System.out.println("Superman leaps the building like a piece of cake.");
		
	}
	
	public void stopBullet() {
		
		System.out.println("Superman is bulletproof.");
		
	}
	
	

}
