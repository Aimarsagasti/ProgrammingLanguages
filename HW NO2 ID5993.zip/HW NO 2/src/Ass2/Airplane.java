package Ass2;

public class Airplane implements Flyer{

	
	public void takeoff() {
		
		System.out.println("Airplane will take off from Skopje Airport.");
		
	}

	
	public void land() {
		System.out.println("Airplane has just landed at Ohrid Airport.");
		
	}

	
	public void fly() {
		System.out.println("The plane flies approximately at 10000 meters above the sea-level.");
		
	}

}
