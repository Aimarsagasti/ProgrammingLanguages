package ass1;

import java.util.*;
import java.util.stream.Collectors;



public class Demo {

	public static void main(String[] args) {
		
		
		List <Book> bookList = new ArrayList<Book>();
		List <Book> sortedBooks;
		
		
		
		Book[] book = new Book[5];
		
		
		
		book[0] = new Book("Game of thrones", "George Martin", 30.99, 500);
		book[1] = new Book("Harry Potter", "J.K Rowling", 15.99, 250);
		book[2] = new Book("Los Miserables", "Victor Hugo", 213.99, 300);
		book[3] = new Book("100 años de soledad", "Gabriel Garcia Marquez", 27, 400);
		book[4] = new Book("El principito", "Antoine de saint exupery", 15.5, 1001);
		
		
		for(int i=0; i < 5; i++) {
			
			bookList.add(book[i]);
			
		}
		
		
		sortedBooks = bookList.stream().sorted(Comparator.comparing(Book::getTitle)).collect(Collectors.toList());
		
		sortedBooks.forEach(Book::printatributes);
		
		
		Book mostexpensive = bookList.stream().max(Comparator.comparing(Book::getPrice)).orElse(null);		
		
		Book lessexpensive = bookList.stream().min(Comparator.comparing(Book::getPrice)).orElse(null);	
		
		
		System.out.print("The most expensive book is: ");
		mostexpensive.printatributes();
		
		System.out.print("The less expendive book is: ");
		lessexpensive.printatributes();
		
		List <Book> filteredBook = bookList.stream().filter(Book -> Book.getQuantity() > 1000).collect(Collectors.toList());
		
		System.out.print("The books that has gos more quantity than 1000 are: ");
		
		filteredBook.forEach(Book::printatributes);
		
	}

}
