
public abstract class Animal {
	
	protected String name;
	
	public Animal() {
		
		name="";
		
	}
	
	public Animal(String n) {
		
		name = n;
		
	}
	
	public void onomatopeia() {
		
		System.out.println("There is no onomatopeia for animals");
		
	}
	
	public abstract void traits();

}
