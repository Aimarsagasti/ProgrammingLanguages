


public class Dog extends Animal{
	
	
	public Dog(String name) {
		
		super(name);
		
	}
	
	public void onomatopeia() {
		
		System.out.println("The onomatopeia for "+name+" is ARF ARF");
		
	}
	
	public void traits() {}

}
