


public class Lion extends Animal{
	
	
	public Lion(String name) {
		
		super(name);
		
		
	}
	
	public void onomatopeia() {
		
		System.out.println("The onomatopeia for "+name+" is ROAR");
		
	}
	
	public void traits() {}

}
