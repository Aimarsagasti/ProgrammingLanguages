
public class ZOO {

	public static void main(String[] args) {
		
		
		Animal[] animals = new Animal[5];
		
		animals[0] = new Dog("Thor");
		animals[1] = new Dog("Gutxi");
		animals[2] = new Lion("Simba");
		animals[3] = new Frog("kermit");
		animals[4] = new SARA_MOUNTAIN_DOG("Rex");
		//animals[5] = new Animal();
		
		
		for (int i = 0; i < animals.length; i++) {
			
			animals[i].onomatopeia();
			
		}
		
		if(animals[4] instanceof SARA_MOUNTAIN_DOG) {
			
			animals[4].traits();
			
		}
		
	}

}
