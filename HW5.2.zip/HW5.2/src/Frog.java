
public class Frog extends Animal {

	public Frog(String name) {

		super(name);

	}

	public void onomatopeia() {

		System.out.println("The onomatopeia for " + name + " is CROAK");

	}
	
	public void traits() {}

}
