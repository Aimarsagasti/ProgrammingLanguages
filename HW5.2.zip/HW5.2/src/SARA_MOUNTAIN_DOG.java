


public class SARA_MOUNTAIN_DOG extends Dog{

	public SARA_MOUNTAIN_DOG(String name) {
		
		super(name);
		
		
	}
	
	public void onomatopeia() {
		
		System.out.println("The onomatopeia for "+name+" is ARF ARF");
		
	}
	
	public void traits() {
		
		
		System.out.println("Sara mointain dog REX is the Macedonian champion for 2009");
	}
	
	
	
}
