
public class Brass extends Instrument{

	
	
	public Brass(String b) {
		super(b);
		
	}

	@Override
	public void play() {
		
		System.out.println("The brass instrument"+brand+" is playing");
		
	}

	@Override
	public void tweaking() {
		
		
	}
	
	public String Whatisplaying() {
		
		return "Brass";
		
	}

	@Override
	public int type() {
		
		return 2;
	}

}
