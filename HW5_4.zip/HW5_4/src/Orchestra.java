
public class Orchestra {

	public static void main(String[] args) {
		
		Instrument[] orchestra = new Instrument[5];
		
		orchestra[0] = new Brass("Amati");
		
		orchestra[1] = new Percussion("Conga");

		orchestra[2] = new Wired("Stradicarius");
		
		orchestra[3] = new Trumpet("Velklant");
		
		orchestra[4] = new Guitar("Yamaha");
		
		
		
		for(int i = 0; i < orchestra.length; i++) {
			
			orchestra[i].tweaking();
			
		}
		
		
		for(int i = 0; i < orchestra.length; i++) {
			
			orchestra[i].play();
			
		}
		
		System.out.println("\nThe orchestra consist of: ");
		
		for(int i = 0; i < orchestra.length; i++) {
			
			
			System.out.println(orchestra[i].Whatisplaying());
			
			
		}
		
		int w = 0, b = 0, p = 0;
		
		
		for(int i = 0; i < orchestra.length; i++) {
			
			switch(orchestra[i].type()) {
			
				case 1: w++;
					break;
				case 2: b++;
					break;
				case 3: p++;
					break;
			}
			
		}
		
		System.out.println("\nIn the orchestra there are "+w+" wired, "+b+" brass and "+p+" percussion instruments");
		
		
		
		
	}
	
}
