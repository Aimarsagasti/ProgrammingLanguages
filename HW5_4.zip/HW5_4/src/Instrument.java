
public abstract class Instrument {
	
	protected String brand;
	
	public Instrument(String b) {
		
		brand = b;
		
	}
	
	public String Whatisplaying() {
		
		return "Instrument";
		
	}
	
	public abstract void play();
	
	public abstract void tweaking();	
	
	public abstract int type();

}
