
public class Trumpet extends Brass{

	public Trumpet(String b) {
		super(b);
		
	}
	
	public void play() {
		
		System.out.println("The instrument trumpet "+brand+" is playing");
		
	}
	
	public void tweaking() {
		
		System.out.println("Trumpet tweaking");
		
	}

}
