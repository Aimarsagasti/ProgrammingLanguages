
public class Percussion extends Instrument{

	
	
	
	
	public Percussion(String b) {
		super(b);
		
	}

	@Override
	public void play() {
		
		System.out.println("The percussion instrument "+brand+" is playing");
		
	}

	@Override
	public void tweaking() {
		
		
	}
	
	public String Whatisplaying() {
		
		return "Percussion";
		
	}

	@Override
	public int type() {
		
		return 3;
	}

}
