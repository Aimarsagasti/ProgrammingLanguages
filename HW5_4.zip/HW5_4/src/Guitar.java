
public class Guitar extends Wired{

	
	public Guitar(String brand) {
		super(brand);
		
	}
	
	public void play() {
		
		System.out.println("The instrument guitar "+brand+" is playing");
		
	}
	
	public void tweaking() {
		
		System.out.println("Guitar tweaking");
		
	}
	
public String Whatisplaying() {
		
		return brand+" Guitar";
		
	}
	
	
}
