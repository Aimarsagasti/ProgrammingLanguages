
public class Wired extends Instrument{
	
	
	
	public Wired(String brand) {
		
		super(brand);
		
	}
	
	public String Whatisplaying() {
		
		return "Wired";
		
	}

	@Override
	public void play() {
		
		System.out.println("The wired instrument"+brand+" is playing");
		
	}
	
	

	@Override
	public void tweaking() {
		// TODO Auto-generated method 
		
	}

	@Override
	public int type() {
		
		return 1;
	}

}
