
public class Car {

	private String type;

	private int no_seats;

	private String fuel;

	private String body_color;

	public Car (String type, int seats, String fuel, String body_color){
	
		this.type = type;
		
		this.no_seats = seats;
		 
		this.fuel = fuel;
		
		this.body_color = body_color;
	
	}
	
	public void info() {
		
		
		System.out.println("The cars characteristics are: "+type+", "+no_seats+
				", "+fuel+", "+body_color);
		
		
	}

	public String getType() {

		return type;

	}

	public int getNo_seats() {

		return no_seats;

	}

	public String getFuel() {

		return fuel;

	}

	public String getBody_color() {

		return body_color;

	}

	public void setType(String type) {

		this.type = type;

	}

	public void setNo_seats(int seats) {

		this.no_seats = seats;

	}

	public void setFuel(String fuel) {

		this.fuel = fuel;

	}

	public void setBody_color(String body_color) {

		this.body_color = body_color;

	}

}
