
public class Vehicle {

	public static void main(String[] args) {
		
		
		Car car1 = new Car("BMW", 5, "diesel", "blue");
		Car car2 = new Car("Mercedes", 4, "Diesel", "red");
		
		System.out.println("The first cars characteristics are: "+car1.getType()+", "+car1.getNo_seats()+
				", "+car1.getFuel()+", "+car1.getBody_color());
		
		System.out.println("The second cars characteristics are: "+car2.getType()+", "+car2.getNo_seats()+
				", "+car2.getFuel()+", "+car2.getBody_color());

		
		
		car2.setBody_color("black");
		car2.setFuel("Diesel");
		car2.setNo_seats(6);
		car2.setType("Audi");
		
		
		System.out.println("The second cars characteristics are: "+car2.getType()+", "+car2.getNo_seats()+
				", "+car2.getFuel()+", "+car2.getBody_color());
		
		
		car1.info();
		car2.info();
		
		if(car1.getNo_seats() > car2.getNo_seats()) {
			
			System.out.println("Car1 has got more seats than car2: "+car1.getNo_seats());
			
		}else {
			
			System.out.println("Car2 has got more seats than car1: "+car2.getNo_seats());
			
		}
		
		
	}

}
