


public class Triangle implements Two_D_Shape {

	
	private float sideA, sideB, sideC, height, perimeter, area;
	
	public Triangle(int sideA, int sideB, int sideC, int height) {
		
		this.height = height;
		this.sideB = sideB;
		this.sideA = sideA;
		this.sideC = sideC;
		
		System.out.println("A new triangle is created.");
		
	}
	
	public boolean rectangular() {
		
		if( Math.pow(sideA, 2)+ Math.pow(sideB, 2) == Math.pow(sideC, 2)) {
			
			return true;
			
			
		}else {
			
			return false;
			
		}
		
		
		
	}
	
	
	public void parameters() {
		
		System.out.println("sideA: "+sideA+" , sideB: "+sideB+" , sideC: "+sideC);
		
	}

	
	public float area() {
		
		area = (sideA * sideB)/2;
		
		return 0;
	}

	
	public float perimeter() {
		
		perimeter = sideA + sideB + sideC;
		
		return perimeter;
	}

}
