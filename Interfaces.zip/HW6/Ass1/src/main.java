
public class main {
	
	
	public static void main(String[] args) {
	
		Triangle T1 = new Triangle(3,5,6,3);
		Sphere B1 = new Sphere(4);
		Two_D_Shape T2 = new Triangle(8,2,10,16);
		Two_D_Shape B2 = new Sphere(3);
		Three_D_shape B3 = new Sphere(7);
		
		
		
		System.out.println("The area of the triangle is: "+T1.area());
		System.out.println("The perimeter of the triangle is: "+T1.perimeter());
		System.out.println("Is the triangle rectangular? "+T1.rectangular());
		
		
		System.out.println("The area of the sphere is: "+B1.area());
		System.out.println("The perimeter of the sphere is: "+B1.perimeter());
		System.out.println("The volume of the sphere is: "+B1.volume());
		
		
		System.out.println("The area of the triangle 2 is: "+T2.area());
		System.out.println("The perimeter of the triangle 2 is: "+T2.perimeter());
		//System.out.println("Is the triangle 2 rectangular? "+T2.rectangular());
			
		
		System.out.println("The area of the sphere is: "+B2.area());
		System.out.println("The perimeter of the sphere is: "+B2.perimeter());
		//System.out.println("The volume of the sphere is: "+B2.volume());
		
		
		//System.out.println("The area of the sphere is: "+B3.area());
		//System.out.println("The perimeter of the sphere is: "+B3.perimeter());
		System.out.println("The volume of the sphere is: "+B3.volume());
		
	
	
	}

}
