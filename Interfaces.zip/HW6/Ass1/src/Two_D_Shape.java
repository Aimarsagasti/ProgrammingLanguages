
public interface Two_D_Shape {
	
	final double PI = 3.14;
	
	
	
	abstract void parameters();
	
	abstract float area();
	
	abstract float perimeter();
	

}
