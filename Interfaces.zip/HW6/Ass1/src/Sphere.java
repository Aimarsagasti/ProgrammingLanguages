
public class Sphere implements Two_D_Shape, Three_D_shape {

	
	private float radius, area, perimeter, volume;
	
	
	
	public Sphere(float radius){
		
		this.radius = radius;
		
		System.out.println("A new sphere has been created.");
		
		
	}
	
	
	
	public void parameters() {
		
		System.out.println("The value of the radius is: "+radius);
		
	}
	
	

	
	public float area() {
		
		area = (float) (4* Two_D_Shape.PI * Math.pow(radius, 2));
		
		return area;
	}

	
	public float perimeter() {
		
		perimeter = (float) (2 * Two_D_Shape.PI *radius);
		
		return perimeter;
	}

	
	
	
	public float volume() {
		
		volume = (float) (4/3 * Two_D_Shape.PI * Math.pow(radius, 3));
		
		return volume;
	}
	
	
	
	

}
