
public interface Three_D_shape {
	
	
	abstract float volume();
	

}
