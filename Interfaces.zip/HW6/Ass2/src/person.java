
public class person {
	
	protected String p_name;
	
	public person(String p_name){
		
		this.p_name = p_name;
		
	}
	

}
