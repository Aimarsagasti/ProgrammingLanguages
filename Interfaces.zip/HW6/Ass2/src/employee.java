import java.util.Random;

public class employee extends person implements average{

	
	private int no_salaries;
	private int salary[] = new int[12];
	private float average = 0;
	
	Random R = new Random();
	
	public employee(String name, int n) {
		
		super(name);
		no_salaries = n;
		
		for(int i = 0; i < salary.length; i++) {
			
			salary[i] = R.nextInt(0, 30000);
			
		}
		
	}
	
	
	public float Average() {
		
		if(no_salaries != 0) {
		
			for(int i = 0; i < no_salaries; i++) {
				
				average = average + salary[i];
				
			}
			
			average = average / no_salaries;
			
			return average;
		
		}else {
		
			return 0;
			
		}
		
		
	}

}
