
public class Ass2 {

	public static void main(String[] args) {
		
		
		employee [] Emp = new employee[6];
		
		student [] Stu = new student[3];
		
		Emp[0] = new employee("Sabin", 1);
		Emp[1] = new employee("Maria", 1);
		Emp[2] = new employee("Miguel", 1);
		Emp[3] = new employee("Marisa", 1);
		Emp[4] = new employee("Leire", 1);
		Emp[5] = new employee("Joseba", 1);
		
		
		Stu[0] = new student("Aimar", 4, Emp[0], Emp[1]);
		Stu[1] = new student("Saioa", 4, Emp[0], Emp[1]);
		Stu[2] = new student("Iera", 4, Emp[0], Emp[1]);
		
		
		for(int i = 0; i < Stu.length; i++) {
			

			
			System.out.println("The name of the "+i+" student is: "+Stu[0].p_name);
			System.out.println("The average of the "+i+" student is: "+Stu[i].getAverage());
			System.out.println("The name of the first parents of the "+i+" student is: "+Stu[i].getR1().p_name);
			System.out.println("The average salary of the first parents of the "+i+" student is: "+Stu[i].getR1().Average());
			System.out.println("The name of the first parents of the "+i+" student is: "+Stu[i].getR2().p_name);
			System.out.println("The average salary of the first parents of the "+i+" student is: "+Stu[i].getR2().Average());
			System.out.println("The rate of the "+i+" student is: "+Stu[i].rate());
		}
		
		float rate = 0;
		int aux = 0;
		
		for(int i = 0; i < Stu.length; i++) {
			
			if(rate < Stu[i].rate()) {
				
				rate = Stu[i].rate();
				aux = i;
				
			}
			
		}
		
		System.out.println(Stu[aux].p_name+" will get the scholarship.");
		

	}

}
