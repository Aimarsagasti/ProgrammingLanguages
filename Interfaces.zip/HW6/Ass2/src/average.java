
public interface average {
	
	
	public float Average();
	
	

}
