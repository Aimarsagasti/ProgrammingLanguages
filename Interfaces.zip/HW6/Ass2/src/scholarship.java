
public interface scholarship {

	public float rate();
	
	
}
