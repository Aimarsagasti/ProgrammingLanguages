import java.util.Random;

public class student extends person implements scholarship, average{
	
	Random R = new Random();

	
	private int no_grades;
	
	employee r1;
	employee r2;
	
	protected int [] grade = new int[6];
	
	private float average = 0;
	
	
	public student(String p_name, int n, employee r1, employee r2) {
		super(p_name);
		
		this.r1 = r1;
		this.r2 = r2;
		
		for(int i=0; i< 6; i++) {
			
			grade[i] = R.nextInt(5, 10);
			
		}

		
	}


	
	
	
	
	
	
	public employee getR1() {
		return r1;
	}








	public void setR1(employee r1) {
		this.r1 = r1;
	}








	public employee getR2() {
		return r2;
	}








	public void setR2(employee r2) {
		this.r2 = r2;
	}








	public float getAverage() {
		return average;
	}








	public void setAverage(float average) {
		this.average = average;
	}








	public float Average() {
		
		
		
		for(int i = 0; i < grade.length; i++) {
			
			average = average + grade[i];
			
		}
		
		average = average / grade.length;
		
		return average;
	}

	
	public float rate() {
		
		float Points;
		
		Points = (average * 6 + (60000-(r1.Average()+r2.Average())) * 4);
		
		
		return Points;
	}
	
	

}
