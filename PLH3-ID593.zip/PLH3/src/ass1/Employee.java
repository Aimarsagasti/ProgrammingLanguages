package ass1;

public class Employee extends Person{
	
	
	int employeeld;
	String department;
	private int securityClearance;
	
	
	
	public Employee(String firstName, String lastName, String dob, int employeeld, String department, int securityClearance) {
		super(firstName, lastName, dob);
		this.employeeld = employeeld;
		this.department = department;
		this.securityClearance = securityClearance;
	}
	
	
	
	
	
	
	
	public int getEmployeeld() {
		return employeeld;
	}
	public void setEmployeeld(int employeeld) {
		this.employeeld = employeeld;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public int getSecurityClearance() {
		return securityClearance;
	}
	public void setSecurityClearance(int securityClearance) {
		this.securityClearance = securityClearance;
	}
	
	
	
	
}
