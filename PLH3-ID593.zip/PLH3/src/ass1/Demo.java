package ass1;

import java.io.*;
import java.util.*;

public class Demo {

	public static void main(String[] args) {
		
		
		Employee e1 = new Employee("Aimar", "Sagastizabal", "24/05/2001", 50, "Amazon", 100);
		
		Employee e2 = null;
		
		
		System.out.println("Info: "+e1.getFirstName()+", "+e1.getLastName()+", "+e1.getDob()+
				", "+e1.getEmployeeld()+", "+e1.getDepartment()+", "+e1.getSecurityClearance());
		
		
		
		try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("Employees.txt "));){
			
			out.writeObject(e1);
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
		
		
		try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("Employees.txt"));){
			
			
			e2 = (Employee) in.readObject();
			
			
		} catch (IOException |  ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(e2 != null) {
			
			System.out.println("The object has been read successfully");
			
		}
		
		
		System.out.println("\n\nInfo: "+e2.getFirstName()+", "+e2.getLastName()+", "+e2.getDob()+
				", "+e2.getEmployeeld()+", "+e2.getDepartment()+", "+e2.getSecurityClearance());

	}

}
