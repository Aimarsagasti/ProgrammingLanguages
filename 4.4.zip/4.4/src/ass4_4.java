import java.util.function.IntBinaryOperator;

public class ass4_4 {

	public static void main(String[] args) {
		
		
		for(int i = 0; i < args.length; i++) {
			
			System.out.println("value "+i+" is: "+args[i]);
			
		}
		
		
		int num1 = Integer.parseInt(args[2]);
		
		System.out.println("The value of args[0] in decimal is: "+num1);
		
		String num2 = Integer.toBinaryString(Integer.parseInt(args[2]));
		
		System.out.println("The value of args[0] in binary is: "+num2);
		
		num2 = Integer.toOctalString(num1);
				
		System.out.println("The octal value of: "+args[2]+" is: "+num2);
		
		
		num2 = Integer.toHexString(num1);
		
		System.out.println("The hexadecimal value of: "+args[2]+" is: "+num2);
		
		
	}

}
