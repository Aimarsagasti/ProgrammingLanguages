
public class Ass2 {

	public static void main(String[] args) {

		Player[] LA = new Player[5];

		Player[] Miami = new Player[5];

		LA[0] = new Player("LeBron James", "LA");
		LA[1] = new Player("Anthony Davis", "LA");
		LA[2] = new Player("Russell Westbrook", "LA");
		LA[3] = new Player("Kentavious Caldwell-Pope", "LA");
		LA[4] = new Player("Talen Horton-Tucker", "LA");

		Miami[0] = new Player("Jimmy Butler", "Miami");
		Miami[1] = new Player("Bam Adebayo", "Miami");
		Miami[2] = new Player("Tyler Herro", "Miami");
		Miami[3] = new Player("Duncan Robinson", "Miami");
		Miami[4] = new Player("Goran Dragic", "Miami");

		int puntosLA = 0, puntosmiami = 0;

		for (int i = 0; i < LA.length; i++) {

			System.out.println("The LAs "+i+" player is: " + LA[i].getName() + " and has got " + LA[i].getPoints() + " points.");
			puntosLA = puntosLA + LA[i].getPoints();

		}
		
		System.out.println();

		for (int i = 0; i < Miami.length; i++) {

			System.out.println("The Miamis "+i+" player is: " + Miami[i].getName() + " and has got " + Miami[i].getPoints() + 
							" points.");
			
			puntosmiami = puntosmiami + Miami[i].getPoints();

		}
		
		System.out.println();
		
		System.out.println("The total points of LA are: "+puntosLA+" and the total points of Miami are: "+puntosmiami);
		
		if(puntosLA > puntosmiami) {
			
			System.out.println("The winners are LA");
			
		}else {
			
			System.out.println("The winners are Miami Heat");
		}

	}

}
