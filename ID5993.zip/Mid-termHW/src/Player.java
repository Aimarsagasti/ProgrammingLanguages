
public class Player {
	
	private String name;
	private int points;
	private String team;
	
	
	public Player(String name, String team) {
		
		this.name = name;
		this.team = team;
		
		points = (int)(Math.random()*100)%50;
		
	}
	
	//Getters and Setters


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getPoints() {
		return points;
	}


	public void setPoints(int points) {
		this.points = points;
	}
	
	
	
	public Player MVP(Player[] p) {
		
		int aux = 0;
		int x = 0;
		
		for(int i = 0; i < p.length ; i++) {
			
			if(aux < p[i].getPoints()) {
				
				aux = p[i].getPoints();
				
				x = i;
				
			}
			
		}
		
		
		return p[x];
	}
	
	

}
