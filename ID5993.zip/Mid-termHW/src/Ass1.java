

import java.util.*;

public class Ass1 {
	
	public static void main(String[] args) {
		
		
		System.out.println("Introduce some numbers with a space between them: ");
		
		int nums [] = new int[args.length];
		
		for(int i = 0; i < args.length; i++) {
			
			nums[i] = Integer.parseInt(args[i]);
			
		}
		
		
		int max = 0, min = 1000000;
		
		for(int i = 0; i < nums.length ; i++) {
			
			System.out.println("The num of "+i+" is: "+nums[i]);
			
			if(min > nums[i]) {
				
				min = nums[i];
				
			}
			
			if (max < nums[i]) {
				
				max = nums[i];
				
			}
			
		}
		
		System.out.println("The min number is: "+min+" and the max num is: "+max);
		
		
	}

}
