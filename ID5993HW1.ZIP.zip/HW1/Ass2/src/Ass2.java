import java.util.*;
import java.math.*;



public class Ass2 {

	public static void main(String[] args) {
		
		String name1, name2, name3, name4;
		
		double g1, g2, g3, g4, state_taxes, personal_tax, net_salary;
		
		name1 = "Aimar Sagastizabal";
		name2 = "Pepe Amorrortu";
		name3 = "Mikel Lopez";
		
		
		
		
		g1 = 54392;
		g2 = 50876;
		g3 = 43897;
		
		
		state_taxes = g1 * 0.284;
		
		if((g1 - state_taxes - 7000) > 0) {
			
			personal_tax = (g1 - state_taxes - 7000)*0.1;
			
		}else {
			
			personal_tax = 0;
		}
		
		net_salary = g1 - state_taxes - personal_tax;
		
		
		
		System.out.println("The employee: "+name1+" with Gross salary of: "+g1+" MKD,"
				+ " will get NET salary: "+Math.round(net_salary)+ " MKD");
		System.out.println("State taxes are: "+Math.round(state_taxes)+" MKD");
		
		System.out.println("Personal tax is: "+Math.round(personal_tax)+" MKD\n");
		
		
state_taxes = g2 * 0.284;
		
		if((g2 - state_taxes - 7000) > 0) {
			
			personal_tax = (g2 - state_taxes - 7000)*0.1;
			
		}else {
			
			personal_tax = 0;
		}
		
		net_salary = g2 - state_taxes - personal_tax;
		
		
		
		System.out.println("The employee: "+name2+" with Gross salary of: "+g2+" MKD,"
				+ " will get NET salary: "+Math.round(net_salary)+ " MKD");
		System.out.println("State taxes are: "+Math.round(state_taxes)+" MKD");
		
		System.out.println("Personal tax is: "+Math.round(personal_tax)+" MKD\n");
		
		
		
state_taxes = g3 * 0.284;
		
		if((g3 - state_taxes - 7000) > 0) {
			
			personal_tax = (g3 - state_taxes - 7000)*0.1;
			
		}else {
			
			personal_tax = 0;
		}
		
		net_salary = g3 - state_taxes - personal_tax;
		
		
		
		System.out.println("The employee: "+name3+" with Gross salary of: "+g3+" MKD,"
				+ " will get NET salary: "+Math.round(net_salary)+ " MKD");
		System.out.println("State taxes are: "+Math.round(state_taxes)+" MKD");
		
		System.out.println("Personal tax is: "+Math.round(personal_tax)+" MKD\n");
		
		
		
	}

}














