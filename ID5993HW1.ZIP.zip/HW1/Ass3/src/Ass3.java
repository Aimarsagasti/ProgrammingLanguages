
import java.util.*;


public class Ass3 {

	public static void main(String[] args) {
		
		
		Scanner S = new Scanner(System.in);
		
		String name = new String();
		
		char middle;
		
		System.out.print("Introduce un nombre: ");
		
		name = S.nextLine();
		
		System.out.println("My string is: "+name);
		
		System.out.println("The fisrt character is: "+name.charAt(0));
		
		System.out.println("The last character is: "+name.charAt(name.length()- 1));
		
		if((name.length()%2) == 0) {
			
			middle = name.charAt(name.length() /2);
			
			System.out.println("Its middle character is: "+ middle);
			
		}else {
			
			middle = name.charAt(Math.round(name.length()/2));
			
			System.out.println("Its middle chahracter is: "+ middle);
			
		}
		
		int c1, c2, c3;
		
		c1 = (int)name.charAt(0);
		c2 = (int) name.charAt(name.length()- 1);
		c3 = (int) middle;
		
		int sum = c1 + c2 + c3;
		
		
		System.out.println("The sum of these 3 characters is: "+sum);
		
		if(c1 > c2) {
			if(c1 > c3) {
				System.out.println("The biggest character of these 3 is: "+(char)c1+ " with code of: "+c1);
			}else {
				System.out.println("The biggest character of these 3 is: "+(char)c3+ " with code of: "+c3);
			}
			
		}else if(c2 > c3) {
			
			System.out.println("The biggest character of these 3 is: "+(char)c2+ " with code of: "+c2);
			
		}else {
			
			System.out.println("The biggest character of these 3 is: "+(char)c3+ " with code of: "+c3);
			
		}

	}

}

