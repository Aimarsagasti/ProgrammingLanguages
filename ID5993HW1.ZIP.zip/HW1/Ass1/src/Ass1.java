


import java.util.*;
import java.math.*;




public class Ass1 {

	public static void main(String[] args) {

		float num, num2;
		int num1;

		Scanner S = new Scanner(System.in);

		Random R = new Random();

		num = R.nextFloat(100);

		num1 = (int) num;

		num2 = num - num1;

		System.out.println("The aleatory number is: " + num);

		System.out.println("The integer part of the num is: " + num1);

		System.out.println("The decimal part of the num is: " + num2);

		System.out.println("The code of the number " + num1 + " is: " +(char)num1);

	}

}